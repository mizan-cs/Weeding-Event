<div class="title">
    <h1>{{setting('site.title')}}</h1>
    <p class="date">{{setting('site.event_date')}}</p>
</div>

<div class="slider">
    <div class="slide-item slide-img-1"></div>
    <div class="slide-item slide-img-2"></div>
</div> <!-- end of slider -->