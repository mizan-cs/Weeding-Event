<?php /* C:\Users\Mizan\Desktop\fiverr\renato2715\event-weed\resources\views/sections/slider.blade.php */ ?>
<div class="title">
    <h1><?php echo e(setting('site.title')); ?></h1>
    <p class="date"><?php echo e(setting('site.event_date')); ?></p>
</div>

<div class="slider">
    <div class="slide-item slide-img-1"></div>
    <div class="slide-item slide-img-2"></div>
</div> <!-- end of slider -->