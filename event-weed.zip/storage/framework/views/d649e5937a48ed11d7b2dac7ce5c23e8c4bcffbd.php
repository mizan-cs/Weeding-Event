<?php /* C:\Users\Mizan\Desktop\fiverr\renato2715\event-weed\resources\views/sections/top-nav.blade.php */ ?>
<ul class="nav navbar-nav">
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e($menu_item->url); ?>"><?php echo e($menu_item->title); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
